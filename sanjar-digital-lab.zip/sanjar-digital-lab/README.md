# SASS / SANJAR — The Digital Lab

A cinematic portfolio for Mohammed Shaheed Sanjar in Mocha Brown (#6F4E37), Platinum Silver (#E5E4E2) and Pale Lavender (#E6E0F8), with black/white structural neutrals. A persistent procedural WebGL Core morphs through project worlds, research, a connected technology system, an interactive Lab, an editorial engineering sequence, and a quiet contact finale. The custom **SASS** wordmark sits at the top left on every route.

## Run the delivered website

The prebuilt `dist/` folder runs on any static HTTP host. No API keys, database, or Docker are required.

```bash
python -m http.server 8080 --directory dist
```

Open http://localhost:8080/. Root-relative routes require HTTP serving rather than opening an HTML file directly.

## Build and edit

Node.js 20+ and Python 3 are required to rebuild. Dependencies are pinned with a lockfile.

```bash
npm ci
npm run build
npm run check
```

- `src/home.html`, `src/research.html`, `src/technology.html` — homepage, VISORA AI Lab and technology scene markup.
- `src/content/projects.json` — all seven projects in the owner’s exact order; VISORA is featured.
- `src/content/technologies.json` — categories with verified project mappings.
- `tools/project_content.py` — chapter/case generation and original conceptual diagrams.
- `src/styles/experience.css` — art direction, responsive compositions, fallback and motion rules.
- `src/experience.ts` — progressive initialization and lifecycle.
- `src/core/` — shared-topology procedural geometry, custom GLSL, Three.js renderer and optional bloom.
- `src/motion.ts` — GSAP ScrollTrigger choreography and scene poses.
- `src/ui/` — command palette, cursor, settings, technology graph and Lab interactions.
- `tools/build-pages.py` — metadata, shared SASS header, project notes and policy pages.
- `tools/build.mjs` — static generator and code-split esbuild pipeline.
- `dist/assets/site.css` — base typography and detailed case-study/policy styles.
- `docs/SOURCES.md` — factual provenance and intentional omissions.
- `docs/AUDIT.md`, `docs/validation.json` — implementation assessment and actual verification limits.

## Interaction map

- Native scroll changes geometry, camera, typography and environment. It does not replace normal browser scrolling.
- Cmd+K / Ctrl+K or mobile Explore opens a keyboard-accessible command palette.
- Project perspective buttons reveal concise problem, system, intelligence and evidence notes.
- Technology nodes reveal uses and related projects on focus, tap or hover.
- In the Lab, drag horizontally or use arrow keys on the Core interaction region to rotate it; switch shapes, frequency and sample threshold. Reset restores the experiment.
- Pause Core stops time-based graphics motion. Reduce motion disables the intro and scroll text animation; OS preferences take priority.
- Theme cycles auto, light and dark. Quality toggles adaptive and economy rendering.
- `sudo sanjar` in command search reveals a local structural inspection mode; it is not a real terminal.
- Email, GitHub and LinkedIn use verified destination links. Résumé is requested by email because a verified résumé file was not supplied.

## Graphics and performance

Real Three.js WebGL2 with a custom shader interpolating ten geometry states. Desktop has 4,480 samples; mobile has 1,408. Renderer and optional bloom load dynamically. Pixel ratio and frame cadence are capped; sustained slow frames reduce quality. Rendering pauses when the tab is hidden, and reduced-motion views render on changes. Low-powered devices can choose economy quality. Context loss restores the static illustration. Core content, navigation and local signal controls remain available without WebGL; project information remains readable without JavaScript.

The initial interface bundle is small; Three.js and GSAP arrive as separate modules. See `docs/validation.json` for raw and estimated gzip sizes. These estimates are not measured network timing or Lighthouse scores.

## Deployment

Upload `dist/` to a static host, keeping the route directories. Configure unknown routes to return `404.html` with status 404. No SPA rewrite is required. Vercel configuration is included; its supplemental headers apply only when that host honors them. `.openai/hosting.json` belongs to this existing Sites project and must not be reused as a different project's identity.

The current Site retains owner-private access and noindex metadata. For a later public launch, change audience through hosting, confirm policies and the domain, then regenerate the metadata with:

```bash
python tools/build-pages.py --origin https://YOUR-CONFIRMED-DOMAIN --public
```

This command changes metadata only; it does not grant access. A subsequent default build returns to this delivery's private metadata configuration.

## Privacy and licensing

No application cookies, browser-persistent preferences, analytics, tracking pixels, remote fonts, embeds, external API calls, accounts, contact forms or database. UI input remains in page memory. The hosting sign-in/security layer and email correspondence are separate and described in the policies.

Original presentation, shader geometry, SVGs and source code were created for this project. Three.js is bundled under MIT, GSAP under its Standard License, and Manrope under SIL OFL 1.1. Licensing notices are in `dist/assets/licenses/` and `dist/assets/OFL-Manrope.txt`. Dependencies are self-hosted; no third-party script service is contacted.

## Verified limits

The updated desktop hero and VISORA chapter, SASS logo, project index jump, VISORA System control, command palette and navigation to Research were inspected in the managed browser. Previous-version Lab keyboard/reset checks are recorded separately. The browser has no WebGL2 support, so actual GPU output, bloom and frame rate could not be observed. Mobile device rendering, screen-reader combinations, Lighthouse and complete contrast/zoom audits remain unverified. Source checks and TypeScript compilation do not replace these checks.
