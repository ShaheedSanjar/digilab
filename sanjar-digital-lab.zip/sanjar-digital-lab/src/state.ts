export type Quality = 'auto' | 'full' | 'eco';
export const state = {
  shape: 0, shapeFrom: 0, shapeMix: 1, scale: 1, x: 1.05, y: 0, rotationX: 0.35, rotationY: -0.45,
  rotationZ: -0.2, cameraZ: 7.8, light: 0, opacity: 1,
  emphasis: 0, pointerX: 0, pointerY: 0, pointerVelocity: 0,
  dragX: 0, dragY: 0, labFrequency: 3, labThreshold: 0.35,
  reduced: matchMedia('(prefers-reduced-motion: reduce)').matches,
  paused: false, theme: 'auto' as 'auto'|'light'|'dark', quality: 'auto' as Quality,
  currentScene: 'identity', isDragging: false, wireframe: false, alive: true,
};
export type CoreState = typeof state;
export function signal(name: string, detail?: unknown) {
  window.dispatchEvent(new CustomEvent('sanjar:'+name,{detail}));
}
export function toast(message: string) {
  const el=document.getElementById('toast'); if(!el)return;
  el.textContent=message;
  clearTimeout(toastTimer); toastTimer=window.setTimeout(()=>{el.textContent='';},4500);
}
let toastTimer=0;
