import {WebGLRenderer,Scene,PerspectiveCamera,Group,ShaderMaterial,Points,LineSegments,Vector2,Color,NormalBlending,SRGBColorSpace,ACESFilmicToneMapping} from 'three';
import {createCoreGeometry} from './geometry';
import {vertexShader,fragmentShader} from './shaders';
import {state,signal} from '../state';
import type {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
export function mountCore(container: HTMLElement) {
 const mobile=matchMedia('(max-width:760px)').matches;
 let renderer:WebGLRenderer;
 try{renderer=new WebGLRenderer({alpha:true,antialias:false,powerPreference:mobile?'low-power':'high-performance',failIfMajorPerformanceCaveat:false});}
 catch{signal('core-status',{status:'fallback'});return null;}
 renderer.outputColorSpace=SRGBColorSpace;renderer.toneMapping=ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;
 renderer.setClearColor(0x0b0b0b,1);renderer.domElement.setAttribute('aria-hidden','true');renderer.domElement.className='core-canvas';
 container.append(renderer.domElement);
 const scene=new Scene(),camera=new PerspectiveCamera(mobile?47:38,innerWidth/innerHeight,.1,60),group=new Group();
 scene.add(group);camera.position.z=7.8;
 const geometry=createCoreGeometry(mobile);
 const common={uShape:{value:0},uFrom:{value:0},uMorph:{value:1},uTime:{value:0},uMotion:{value:state.reduced?0:1},uEnergy:{value:0},uPixelRatio:{value:1},uPointer:{value:new Vector2()},uLight:{value:0},uOpacity:{value:1},uEmphasis:{value:0},uFrequency:{value:3}};
 const lineMaterial=new ShaderMaterial({uniforms:{...common,uPoints:{value:0}},vertexShader,fragmentShader,transparent:true,depthWrite:false,blending:NormalBlending});
 const pointMaterial=new ShaderMaterial({uniforms:{...common,uPoints:{value:1}},vertexShader,fragmentShader,transparent:true,depthWrite:false,blending:NormalBlending});
 const lines=new LineSegments(geometry.lines,lineMaterial),points=new Points(geometry.points,pointMaterial);
 lines.frustumCulled=false;points.frustumCulled=false;group.add(lines,points);
 let pixelRatio=Math.min(devicePixelRatio,mobile?1.1:1.6),composer:EffectComposer|null=null,bloomAllowed=!mobile,qualityReduced=false;
 let frame=0,raf=0,previous=0,badFrames=0,slowFrames=0,elapsed=0,stopped=false,dirty=true;
 let lastPose='';
 const bgDark=new Color('#0B0B0B'),bgLight=new Color('#E5E4E2'),bg=new Color();
 const stageStatus=document.getElementById('render-status');
 function resize(){renderer.setPixelRatio(pixelRatio);renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();composer?.setPixelRatio(pixelRatio);composer?.setSize(innerWidth,innerHeight);common.uPixelRatio.value=pixelRatio;dirty=true;}
 resize();
 async function enableBloom(){
  if(!bloomAllowed || state.reduced || state.quality==='eco')return;
  try{
   const [{EffectComposer},{RenderPass},{UnrealBloomPass},{OutputPass}]=await Promise.all([import('three/addons/postprocessing/EffectComposer.js'),import('three/addons/postprocessing/RenderPass.js'),import('three/addons/postprocessing/UnrealBloomPass.js'),import('three/addons/postprocessing/OutputPass.js')]);
   if(stopped)return;
   composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));composer.addPass(new UnrealBloomPass(new Vector2(innerWidth,innerHeight),.16,.35,.85));composer.addPass(new OutputPass());resize();
  }catch{composer=null;}
 }
 // Post-processing loads after the primary scene has rendered, never as a first-paint dependency.
 let bloomTimer=window.setTimeout(enableBloom,1800);
 function mode(){
   const low=state.quality==='eco'||qualityReduced;
   pixelRatio=Math.min(devicePixelRatio,low?1:mobile?1.1:1.6);
   geometry.points.setDrawRange(0,low?Math.floor(geometry.count*.65):Infinity);
   if(stageStatus)stageStatus.textContent=state.reduced?'STILL / WEBGL':state.paused?'PAUSED / WEBGL':low?'ECO / WEBGL':'LIVE / WEBGL';
   resize();dirty=true;
 }
 function render(now:number){
  if(stopped||!state.alive)return;
  raf=requestAnimationFrame(render);
  if(document.hidden){previous=now;return;}
  const delta=previous?Math.min((now-previous)/1000,.1):.016;
  const cap=mobile||state.quality==='eco'||qualityReduced?30:45;
  if(previous&&now-previous<1000/cap-1)return;
  previous=now;
  if(!state.reduced&&!state.paused)elapsed+=delta;
  const light=state.theme==='light'?1:state.theme==='dark'?0:state.light;
  const pose=[state.shape,state.shapeFrom,state.shapeMix,light,state.x,state.y,state.scale,state.rotationX,state.rotationY,state.rotationZ,state.cameraZ,state.opacity,state.dragX,state.dragY].join(',');
  const changed=lastPose!==pose;
  if((state.reduced||state.paused)&&!changed&&!dirty)return;
  lastPose=pose;dirty=false;
  const anim=state.reduced||state.paused?0:1;
  common.uTime.value=elapsed;common.uMotion.value=anim;common.uShape.value=state.shape;common.uFrom.value=state.shapeFrom;common.uMorph.value=state.shapeMix;
  common.uLight.value=light;common.uOpacity.value=state.opacity;
  common.uEmphasis.value=state.emphasis;common.uFrequency.value=state.labFrequency;
  common.uEnergy.value+=(Math.min(state.pointerVelocity,.8)*anim-common.uEnergy.value)*.08;
  common.uPointer.value.lerp(new Vector2(state.pointerX,state.pointerY),.07);
  const x=mobile?state.x*.1:state.x;
  const positionEase=anim?.09:1,rotationEase=anim?.06:1;
  group.position.x+=(x-group.position.x)*positionEase;
  group.position.y+=((state.y+(mobile?.45:0))-group.position.y)*positionEase;
  group.rotation.x+=(state.rotationX+state.dragY+(state.pointerY*.06)*anim-group.rotation.x)*rotationEase;
  group.rotation.y+=(state.rotationY+state.dragX+(state.pointerX*.09+Math.sin(elapsed*.14)*.025)*anim-group.rotation.y)*rotationEase;
  group.rotation.z+=(state.rotationZ-group.rotation.z)*rotationEase;
  const scale=state.scale*(mobile?.78:1);group.scale.setScalar(scale);
  camera.position.z=state.cameraZ+(Math.sin(elapsed*.2)*.045)*anim;camera.position.x=state.pointerX*.035*anim;
  bg.copy(bgDark).lerp(bgLight,light);renderer.setClearColor(bg,1);
  if(composer && light<.1 && !qualityReduced && state.quality!=='eco' && !state.reduced)composer.render();else renderer.render(scene,camera);
  if(frame++===0){document.documentElement.classList.add('core-ready');signal('core-status',{status:'webgl',vertices:geometry.count});mode();}
  if(!state.reduced&&!state.paused&&frame>80){
   if(delta>.047)slowFrames++;badFrames++;
   if(badFrames>100){if(slowFrames>30&&!qualityReduced&&state.quality==='auto'){qualityReduced=true;mode();}slowFrames=0;badFrames=0;}
  }
 }
 const contextLost=(e:Event)=>{e.preventDefault();cancelAnimationFrame(raf);document.documentElement.classList.remove('core-ready');signal('core-status',{status:'fallback'});};
 const contextRestored=()=>{dirty=true;frame=0;previous=0;raf=requestAnimationFrame(render);};
 renderer.domElement.addEventListener('webglcontextlost',contextLost);
 renderer.domElement.addEventListener('webglcontextrestored',contextRestored);
 window.addEventListener('resize',resize,{passive:true});
 window.addEventListener('sanjar:motion',mode);window.addEventListener('sanjar:quality',mode);window.addEventListener('sanjar:theme',()=>{dirty=true;});window.addEventListener('sanjar:render',()=>{dirty=true;});
 document.addEventListener('visibilitychange',()=>{previous=0;dirty=true;});
 raf=requestAnimationFrame(render);
 return {dispose(){stopped=true;cancelAnimationFrame(raf);clearTimeout(bloomTimer);geometry.lines.dispose();geometry.points.dispose();pointMaterial.dispose();lineMaterial.dispose();composer?.dispose();renderer.dispose();renderer.domElement.remove();window.removeEventListener('resize',resize);}};
}
