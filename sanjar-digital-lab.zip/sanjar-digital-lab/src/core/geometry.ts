import {BufferGeometry,Float32BufferAttribute,BufferAttribute} from 'three';
export function createCoreGeometry(mobile: boolean) {
  const cols=mobile?64:112, rows=mobile?22:40;
  const count=cols*rows;
  const positions=Array.from({length:10},()=>new Float32Array(count*3));
  const uv=new Float32Array(count*2),seeds=new Float32Array(count);
  const indices:number[]=[];
  for(let j=0;j<rows;j++) for(let i=0;i<cols;i++){
    const n=j*cols+i,k=n*3,u=i/(cols-1),v=j/(rows-1),a=u*Math.PI*2,b=v*Math.PI*2;
    // A folded annular manifold; this shared topology becomes every subsequent scene.
    const radius=1.65+0.5*Math.cos(b),fold=0.23*Math.sin(a*3);
    const layer=Math.min(4,Math.floor(v*5)),localV=(v*5)%1;
    const square=Math.max(Math.abs(Math.cos(a)),Math.abs(Math.sin(a)));
    const forms=[
      [radius*Math.cos(a),radius*Math.sin(a)*0.84,0.55*Math.sin(b)+fold],
      [(u-.5)*4.8,(v-.5)*3.0+Math.sin(a*2)*.16,Math.sin(a*2+v*2)*.32+Math.sin(b*3)*.16],
      [(u-.5)*4.5,Math.sin(b)*(.75+Math.sin(a*2)*.3),Math.cos(b)*(.75+Math.sin(a*2)*.3)+Math.sin(a*3)*.3],
      [(u-.5)*5.2,Math.sin(u*8)*Math.cos(v*7)*.44+Math.exp(-((u-.6)**2+(v-.5)**2)*22)*1.05,(v-.5)*4.2],
      [(u-.5)*4.4,(v-.5)*3.8,Math.sin(u*8)*Math.cos(v*7)*.75],
      [(u-.5)*4.4,(v-.5)*3.4,(Math.sin(a*3)*Math.sin(b*3))*.34],
      [(layer-2)*.76,(u-.5)*(2.8-layer*.24),(localV-.5)*(2.8-layer*.24)],
      [Math.cos(a)/square*1.95,(Math.floor(v*7)/6-.5)*2.4,Math.sin(a)/square*1.05],
      [(u-.5)*4.6,Math.exp(-Math.pow((u-.5)*4.1,2))*1.7+(v-.5)*.25-.7,(v-.5)*2.5],
      [(u-.5)*4.5,Math.sin(b)*(1.3-u*.8),Math.cos(b)*(1.3-u*.8)+Math.sin(a*2)*.18]
    ];
    for(let f=0;f<10;f++)positions[f].set(forms[f],k);
    uv.set([u,v],n*2);seeds[n]=((i*13+j*17)%97)/97;
    if(i<cols-1)indices.push(n,n+1);
    if(j<rows-1 && i%4===0)indices.push(n,n+cols);
  }
  const points=new BufferGeometry();
  points.setAttribute('position',new Float32BufferAttribute(positions[0],3));
  for(let n=1;n<10;n++)points.setAttribute('aShape'+n,new Float32BufferAttribute(positions[n],3));
  points.setAttribute('aUv',new Float32BufferAttribute(uv,2));points.setAttribute('aSeed',new Float32BufferAttribute(seeds,1));
  const lines=new BufferGeometry();
  for(const [key,attr] of Object.entries(points.attributes))lines.setAttribute(key,attr);
  lines.setIndex(new BufferAttribute(new Uint16Array(indices),1));
  points.computeBoundingSphere();lines.computeBoundingSphere();
  return {points,lines,count};
}
