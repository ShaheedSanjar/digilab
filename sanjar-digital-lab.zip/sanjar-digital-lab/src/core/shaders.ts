export const vertexShader=/* glsl */`
attribute vec3 aShape1;
attribute vec3 aShape2;
attribute vec3 aShape3;
attribute vec3 aShape4;
attribute vec3 aShape5;
attribute vec3 aShape6;
attribute vec3 aShape7;
attribute vec3 aShape8;
attribute vec3 aShape9;
attribute vec2 aUv;
attribute float aSeed;
uniform float uShape;
uniform float uFrom;
uniform float uMorph;
uniform float uTime;
uniform float uMotion;
uniform float uEnergy;
uniform float uPixelRatio;
uniform float uFrequency;
uniform vec2 uPointer;
varying float vLight;
varying float vDepth;
varying float vSeed;
varying vec2 vUv;
vec3 form(float f){
 if(f<0.5)return position;
 if(f<1.5)return aShape1;
 if(f<2.5)return aShape2;
 if(f<3.5)return aShape3;
 if(f<4.5)return aShape4;
 if(f<5.5)return aShape5;
 if(f<6.5)return aShape6;
 if(f<7.5)return aShape7;
 if(f<8.5)return aShape8;
 return aShape9;
}
void main(){
 vec3 p=mix(form(uFrom),form(uShape),uMorph);
 float breathe=sin(uTime*.38+aUv.x*6.283)*.028*uMotion;
 p+=normalize(p+vec3(.001))*breathe;
 float wave=sin(aUv.x*6.283*uFrequency-uTime*.38)*cos(aUv.y*8.0)*.035*uMotion;
 p.z+=wave;
 float nearPointer=exp(-length(p.xy-uPointer*2.3)*1.9);
 p.z+=nearPointer*uEnergy*.16;
 vec4 mv=modelViewMatrix*vec4(p,1.0);
 vDepth=clamp((-mv.z-3.0)/9.0,0.0,1.0);
 vUv=aUv;vSeed=aSeed;
 float band=pow(max(0.0,sin(aUv.x*18.85-uTime*.35)),22.0);
 vLight=.25+(1.0-vDepth)*.42+band*.5+nearPointer*uEnergy*.2;
 gl_Position=projectionMatrix*mv;
 gl_PointSize=clamp((1.0+aSeed)*uPixelRatio*(7.0/-mv.z),1.0,4.0);
}`;
export const fragmentShader=/* glsl */`
uniform float uLight;
uniform float uOpacity;
uniform float uPoints;
uniform float uEmphasis;
varying float vLight;
varying float vDepth;
varying float vSeed;
varying vec2 vUv;
void main(){
 float alpha=1.0;
 if(uPoints>0.5){float d=length(gl_PointCoord-.5);alpha=1.0-smoothstep(.1,.5,d);if(alpha<.01)discard;}
 // The complete material palette: platinum, mocha and pale lavender.
 vec3 platinum=vec3(0.89804,0.89412,0.88627);
 vec3 mocha=vec3(0.43529,0.30588,0.21569);
 vec3 lavender=vec3(0.90196,0.87843,0.97255);
 float signalLine=pow(max(0.0,cos(vUv.y*12.566)),36.0);
 float warmFlow=smoothstep(.35,.65,sin(vUv.x*12.566+vUv.y*3.0));
 vec3 material=mix(platinum,mocha,warmFlow*.78);
 material=mix(material,lavender,signalLine*.48+uEmphasis*.12);
 vec3 color=mix(material,mix(vec3(.04314),mocha,warmFlow),uLight);
 color*=vLight*(1.0+signalLine*.6);
 float opacity=mix(.44,.78,uPoints)*(1.0-vDepth*.45)*uOpacity;
 gl_FragColor=vec4(color,alpha*opacity);
}`;
