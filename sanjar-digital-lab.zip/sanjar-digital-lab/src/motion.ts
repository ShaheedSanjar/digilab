import {gsap} from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import {state,signal} from './state';
gsap.registerPlugin(ScrollTrigger);
type Pose = {shape:number;scale:number;x:number;y:number;rotationX:number;rotationY:number;rotationZ:number;cameraZ:number;light:number;opacity:number};
export const poses:Record<string,Pose>={
 identity:{shape:0,scale:1.18,x:1.1,y:.15,rotationX:.33,rotationY:-.5,rotationZ:-.18,cameraZ:7.8,light:0,opacity:1},
 visora:{shape:6,scale:1.12,x:1.55,y:.1,rotationX:.1,rotationY:-.48,rotationZ:.08,cameraZ:8.4,light:0,opacity:1},
 bankonex:{shape:7,scale:1.05,x:1.25,y:.2,rotationX:.24,rotationY:-.4,rotationZ:-.05,cameraZ:8.5,light:0,opacity:.88},
 "mental-health":{shape:8,scale:1.1,x:1.2,y:.25,rotationX:.2,rotationY:-.25,rotationZ:0,cameraZ:8.3,light:0,opacity:.88},
 investing:{shape:9,scale:1,x:1.4,y:.1,rotationX:.12,rotationY:-.35,rotationZ:-.1,cameraZ:8.1,light:0,opacity:.95},
 finvisor:{shape:1,scale:1.1,x:1.35,y:.25,rotationX:.2,rotationY:-.58,rotationZ:-.2,cameraZ:8,light:0,opacity:1},
 chatbot:{shape:2,scale:1.16,x:.95,y:.4,rotationX:.25,rotationY:.3,rotationZ:-.35,cameraZ:7.6,light:0,opacity:1},
 travel:{shape:3,scale:1.25,x:1.3,y:-.15,rotationX:.6,rotationY:-.4,rotationZ:.1,cameraZ:8.2,light:0,opacity:1},
 research:{shape:6,scale:.9,x:1.2,y:.2,rotationX:.1,rotationY:-.5,rotationZ:-.22,cameraZ:8.3,light:1,opacity:.5},
 stack:{shape:5,scale:1.25,x:0,y:0,rotationX:.05,rotationY:.15,rotationZ:0,cameraZ:8.4,light:0,opacity:.42},
 lab:{shape:0,scale:1,x:1.6,y:0,rotationX:.5,rotationY:-.55,rotationZ:-.3,cameraZ:7.8,light:0,opacity:1},
 observe:{shape:0,scale:.9,x:1.45,y:.1,rotationX:.2,rotationY:-.3,rotationZ:-.2,cameraZ:8.1,light:0,opacity:.8},
 model:{shape:2,scale:1,x:1.45,y:.1,rotationX:.4,rotationY:-.6,rotationZ:-.1,cameraZ:8.1,light:0,opacity:.85},
 build:{shape:1,scale:1,x:1.45,y:.1,rotationX:.2,rotationY:.1,rotationZ:.1,cameraZ:8.1,light:0,opacity:.9},
 test:{shape:4,scale:1,x:1.45,y:.1,rotationX:.5,rotationY:-.4,rotationZ:.2,cameraZ:8.1,light:0,opacity:.85},
 ship:{shape:5,scale:.9,x:1.45,y:.1,rotationX:0,rotationY:0,rotationZ:0,cameraZ:8.1,light:0,opacity:.9},
 about:{shape:0,scale:.7,x:1.65,y:.3,rotationX:.15,rotationY:.5,rotationZ:.12,cameraZ:9,light:0,opacity:.6},
 contact:{shape:0,scale:.09,x:0,y:1.9,rotationX:.3,rotationY:-.1,rotationZ:0,cameraZ:8.3,light:0,opacity:.9},
};
export function applyPalette(){
 const light=state.theme==='light'||(state.theme==='auto'&&state.light>.55);
 document.documentElement.classList.toggle('light-world',light);
 document.documentElement.dataset.theme=state.theme;
 document.querySelectorAll<HTMLElement>('[data-theme-label]').forEach(el=>el.textContent=state.theme.toUpperCase());
 signal('theme');
}
export function mountStory(){
 const nodes=[...document.querySelectorAll<HTMLElement>('[data-scene]')].filter(el=>poses[el.dataset.scene!]);
 if(!nodes.length)return;
 let anchors=nodes.map(el=>({el,name:el.dataset.scene!,top:0}));let oldScene='';
 const header=document.querySelector<HTMLElement>('.site-header');
 let lastY=scrollY;
 function measure(){anchors=anchors.map(item=>({...item,top:item.el.getBoundingClientRect().top+scrollY}));update();}
 function update(){
  const y=scrollY;
  let index=0;
  for(let i=0;i<anchors.length;i++)if(y>=anchors[i].top-innerHeight*.48)index=i;
  const item=anchors[index];const next=poses[item.name];const prev=poses[anchors[Math.max(0,index-1)].name];
  let t=index===0?1:Math.max(0,Math.min(1,(y-(item.top-innerHeight*.48))/(innerHeight*.7)));
  if(state.reduced)t=1;else t=t*t*(3-2*t);
  (Object.keys(next) as (keyof Pose)[]).forEach(key=>{if(key!=='shape')state[key]=prev[key]+(next[key]-prev[key])*t;});
  state.shapeFrom=prev.shape;state.shape=next.shape;state.shapeMix=t;
  if(state.currentScene!==item.name){state.dragX=0;state.dragY=0;}
  state.currentScene=item.name;
  const progress=y/Math.max(1,document.documentElement.scrollHeight-innerHeight);
  document.documentElement.style.setProperty('--scroll-progress',String(progress));
  if(oldScene!==item.name){
   oldScene=item.name;document.documentElement.dataset.scene=item.name;
   document.querySelectorAll<HTMLAnchorElement>('[data-project-index]').forEach(link=>{if(link.dataset.projectIndex===item.name)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});
   const label=document.getElementById('scene-label');if(label)label.textContent=item.el.dataset.sceneLabel||item.name.toUpperCase();
   document.querySelectorAll<HTMLAnchorElement>('[data-nav]').forEach(link=>{
    const section=item.el.closest('[data-nav-section]') as HTMLElement|null;
    const current=link.dataset.nav===(section?.dataset.navSection||item.name);
    if(current)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');
   });
  }
  applyPalette();
  const focused=header?.contains(document.activeElement);
  header?.classList.toggle('nav-receded',y>innerHeight*.8&&y>lastY+3&&!focused&&!state.reduced);
  if(y<lastY-3)header?.classList.remove('nav-receded');lastY=y;
 }
 ScrollTrigger.create({trigger:document.documentElement,start:0,end:'max',onUpdate:update,onRefresh:measure});
 let context:gsap.Context|undefined;
 function buildMotion(){
  context?.revert();
  if(state.reduced){update();return;}
  context=gsap.context(()=>{
   document.querySelectorAll<HTMLElement>('.chapter-title,.scene-heading').forEach(title=>{
    const trigger=title.closest('.scene,.phase,.research-world');
    if(!trigger)return;
    gsap.fromTo(title,{y:55,opacity:.35,filter:'blur(3px)'},{y:0,opacity:1,filter:'blur(0px)',ease:'none',scrollTrigger:{trigger,start:'top 85%',end:'top 30%',scrub:.45}});
   });
   document.querySelectorAll<HTMLElement>('.scene-code').forEach(el=>{
    gsap.fromTo(el,{letterSpacing:'.2em',opacity:.3},{letterSpacing:'.1em',opacity:1,ease:'none',scrollTrigger:{trigger:el,start:'top 93%',end:'top 58%',scrub:true}});
   });
   const heroTitle=document.querySelector('.hero-name');
   if(heroTitle)gsap.to(heroTitle,{y:-65,opacity:.2,scale:.97,transformOrigin:'left center',ease:'none',scrollTrigger:{trigger:'#identity',start:'top top',end:'bottom 15%',scrub:.6}});
   document.querySelectorAll<HTMLElement>('.floating-coordinate').forEach(el=>{
    gsap.fromTo(el,{y:30},{y:-35,ease:'none',scrollTrigger:{trigger:el.closest('.scene'),start:'top bottom',end:'bottom top',scrub:1}});
   });
  });
  ScrollTrigger.refresh();
 }
 window.addEventListener('sanjar:motion',()=>{buildMotion();update();});
 window.addEventListener('sanjar:theme',()=>{ /* palette is applied by controls and the scroll driver */ });
 window.addEventListener('resize',measure,{passive:true});
 document.fonts.ready.then(()=>{measure();ScrollTrigger.refresh();});
 measure();buildMotion();update();
 return ()=>{context?.revert();ScrollTrigger.getAll().forEach(t=>t.kill());};
}
