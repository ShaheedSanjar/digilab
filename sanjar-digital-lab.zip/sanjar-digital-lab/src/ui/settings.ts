import {state,signal,toast} from '../state';
const reducedQuery=matchMedia('(prefers-reduced-motion: reduce)');
let manualMotion=false;
export function palette(){
 const light=state.theme==='light'||(state.theme==='auto'&&state.light>.55);
 document.documentElement.classList.toggle('light-world',light);
 document.documentElement.dataset.theme=state.theme;
 document.querySelectorAll<HTMLElement>('[data-theme-label]').forEach(el=>el.textContent=state.theme.toUpperCase());
 signal('theme');
}
export function toggleTheme(){state.theme=state.theme==='auto'?'light':state.theme==='light'?'dark':'auto';palette();toast('Environment: '+state.theme+'.');}
export function updateMotion(){
 state.reduced=reducedQuery.matches||manualMotion;
 document.documentElement.classList.toggle('motion-off',state.reduced);
 document.querySelectorAll<HTMLButtonElement>('[data-motion]').forEach(b=>{b.setAttribute('aria-pressed',String(state.reduced));b.textContent=reducedQuery.matches?'SYSTEM: STILL':state.reduced?'MOTION: REDUCED':'REDUCE MOTION';b.disabled=reducedQuery.matches;});
 signal('motion');
}
export function toggleMotion(){
 if(reducedQuery.matches){toast('Your system’s reduced-motion preference is active.');return;}
 manualMotion=!manualMotion;updateMotion();toast(state.reduced?'Reduced motion enabled.':'Cinematic motion enabled.');
}
export function togglePause(){
 state.paused=!state.paused;document.querySelectorAll<HTMLElement>('[data-pause]').forEach(el=>{el.setAttribute('aria-pressed',String(state.paused));el.textContent=state.paused?'RESUME CORE':'PAUSE CORE';});signal('motion');
}
export function toggleQuality(){
 state.quality=state.quality==='eco'?'auto':'eco';
 document.querySelectorAll<HTMLElement>('[data-quality]').forEach(el=>{el.textContent=state.quality==='eco'?'QUALITY: ECO':'QUALITY: AUTO';el.setAttribute('aria-pressed',String(state.quality==='eco'));});signal('quality');toast(state.quality==='eco'?'Economy rendering enabled.':'Adaptive rendering enabled.');
}
export function wireframe(){state.wireframe=!state.wireframe;document.documentElement.classList.toggle('wireframe',state.wireframe);toast(state.wireframe?'System structure revealed.':'System inspection closed.');}
export function mountSettings(){
 document.querySelectorAll('[data-motion]').forEach(el=>el.addEventListener('click',toggleMotion));
 document.querySelectorAll('[data-theme]').forEach(el=>el.addEventListener('click',toggleTheme));
 document.querySelectorAll('[data-pause]').forEach(el=>el.addEventListener('click',togglePause));
 document.querySelectorAll('[data-quality]').forEach(el=>el.addEventListener('click',toggleQuality));
 document.querySelectorAll('[data-inspect]').forEach(el=>el.addEventListener('click',wireframe));
 reducedQuery.addEventListener('change',updateMotion);updateMotion();palette();
}
