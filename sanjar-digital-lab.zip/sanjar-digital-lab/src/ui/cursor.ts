import {state,signal} from '../state';
export function mountCursor(){
 const cursor=document.getElementById('system-cursor');
 const fine=matchMedia('(pointer:fine) and (min-width:761px)');
 let px=0,py=0,previousTime=0,pending=false;
 function move(e:PointerEvent){
  const now=performance.now();const dt=Math.max(now-previousTime,16);
  state.pointerVelocity=Math.min(Math.hypot(e.clientX-px,e.clientY-py)/dt*.2,1);
  px=e.clientX;py=e.clientY;previousTime=now;
  state.pointerX=e.clientX/innerWidth*2-1;state.pointerY=-(e.clientY/innerHeight*2-1);
  if(!cursor||!fine.matches||state.reduced)return;
  if(pending)return;pending=true;
  requestAnimationFrame(()=>{cursor.style.transform=`translate3d(${px}px,${py}px,0)`;cursor.classList.add('visible');document.documentElement.classList.add('cursor-on');pending=false;});
 }
 document.addEventListener('pointermove',move,{passive:true});
 document.addEventListener('pointerover',e=>{
  if(!cursor||!fine.matches||state.reduced)return;
  const target=(e.target as Element).closest<HTMLElement>('[data-cursor],a,button,input,summary');
  const word=target?.dataset.cursor||((target?.tagName==='INPUT'&&target?.getAttribute('type')==='range')?'DRAG':target?'OPEN':'');
  cursor.dataset.mode=word.toLowerCase();cursor.querySelector('span')!.textContent=word?word+' ↗':'';
  if(target?.closest('.project-world')){state.emphasis=.65;signal('render');}else state.emphasis=0;
 });
 document.addEventListener('pointerleave',()=>cursor?.classList.remove('visible'));
 document.addEventListener('keydown',()=>{cursor?.classList.remove('visible');document.documentElement.classList.remove('cursor-on');});
 window.addEventListener('sanjar:motion',()=>{if(state.reduced){document.documentElement.classList.remove('cursor-on');cursor?.classList.remove('visible');}});
 document.querySelectorAll<HTMLElement>('.magnetic').forEach(el=>{
  el.addEventListener('pointermove',e=>{if(!fine.matches||state.reduced)return;const r=el.getBoundingClientRect();el.style.translate=`${(e.clientX-r.left-r.width/2)*.08}px ${(e.clientY-r.top-r.height/2)*.1}px`;});
  el.addEventListener('pointerleave',()=>el.style.translate='0 0');
 });
}
