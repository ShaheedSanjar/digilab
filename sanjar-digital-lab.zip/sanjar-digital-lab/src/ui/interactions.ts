import {state,signal,toast} from '../state';
import technologies from '../content/technologies.json';
import projects from '../content/projects.json';
export function mountInteractions(){
 document.querySelectorAll<HTMLElement>('[data-project-world]').forEach(root=>{
  root.querySelectorAll<HTMLButtonElement>('[data-story-step]').forEach(button=>button.addEventListener('click',()=>{
   const id=button.dataset.storyStep!;
   root.querySelectorAll('[data-story-step]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
   root.querySelectorAll<HTMLElement>('[data-story-copy]').forEach(p=>p.hidden=p.dataset.storyCopy!==id);
   state.emphasis=id==='intelligence'?.9:id==='system'?.6:.2;signal('render');
  }));
 });
 const techNodes=document.getElementById('tech-nodes');
 const edges=document.getElementById('tech-edges');
 const spots=[[32,44],[9,23],[55,23],[82,44],[32,76],[58,73],[9,73],[82,77]];
 type Tech=typeof technologies[number]['nodes'][number];
 function chooseTech(button:HTMLButtonElement,data:Tech){
  document.querySelectorAll('[data-tech]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  document.getElementById('tech-title')!.textContent=data.name;
  document.getElementById('tech-use')!.textContent=data.use;
  const related=projects.filter(p=>data.projects.includes(p.id));
  document.getElementById('tech-where')!.textContent=related.length?related.map(p=>p.name.split(' — ')[0]).join(' · '):'Listed in the toolkit. A specific project association has not been supplied.';
  const links=document.getElementById('tech-links')!;links.replaceChildren();
  for(const p of related){const a=document.createElement('a');a.textContent=p.name.split(' — ')[0]+' ↗';a.href='/projects/'+p.slug+'/';links.append(a);}
  edges?.querySelectorAll<SVGElement>('[data-edge]').forEach(e=>{e.style.opacity=e.dataset.edge!.split(' ').includes(data.id)?'1':'.17';});
  state.emphasis=.7;signal('render');
 }
 function category(index:number){
  if(!techNodes||!edges)return;
  const data=technologies[index];techNodes.replaceChildren();edges.replaceChildren();
  document.querySelectorAll<HTMLElement>('[data-tech-category]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.techCategory)===index)));
  for(const [i,t] of data.nodes.entries()){
   const button=document.createElement('button');button.className='tech-node tech-slot-'+i;button.dataset.tech=t.id;button.textContent=t.name;button.setAttribute('aria-pressed','false');
   button.addEventListener('click',()=>chooseTech(button,t));button.addEventListener('focus',()=>chooseTech(button,t));button.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse')chooseTech(button,t);});techNodes.append(button);
   if(i){const path=document.createElementNS('http://www.w3.org/2000/svg','path');const [x,y]=spots[i];path.setAttribute('d',`M320 220Q${(320+x*10)/2} ${y*5} ${x*10} ${y*5}`);path.dataset.edge=data.nodes[0].id+' '+t.id;edges.append(path);}
  }
  const first=techNodes.querySelector<HTMLButtonElement>('button');if(first)chooseTech(first,data.nodes[0]);
 }
 document.querySelectorAll<HTMLElement>('[data-tech-category]').forEach(b=>b.addEventListener('click',()=>category(Number(b.dataset.techCategory))));
 category(0);
 const explanations=[
  'Fashion-MNIST clothing images are the input to the classification task.',
  'Convolutional layers learn visual features from the image data. The planes above are abstract representations, not actual feature maps.',
  'The learned representation supports a clothing-class prediction. No prediction or accuracy score is simulated here.'
 ];
 document.querySelectorAll<HTMLElement>('[data-ai-step]').forEach(b=>b.addEventListener('click',()=>{
  const step=Number(b.dataset.aiStep);document.querySelectorAll('[data-ai-step]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));
  document.querySelector<HTMLElement>('.cnn-study')!.dataset.aiStage=String(step);document.getElementById('ai-stage-copy')!.textContent=explanations[step];state.emphasis=step*.4;signal('render');
 }));
 const drag=document.getElementById('core-drag');
 let dragStart:{x:number;y:number;rx:number;ry:number;pointer:number}|null=null;
 drag?.addEventListener('pointerdown',e=>{if(document.documentElement.classList.contains('webgl-unavailable'))return;dragStart={x:e.clientX,y:e.clientY,rx:state.dragX,ry:state.dragY,pointer:e.pointerId};if(e.pointerType==='mouse'){drag.setPointerCapture(e.pointerId);state.isDragging=true;}});
 drag?.addEventListener('pointermove',e=>{if(!dragStart)return;const dx=e.clientX-dragStart.x,dy=e.clientY-dragStart.y;if(Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)){state.isDragging=true;drag.setPointerCapture(e.pointerId);}if(state.isDragging){state.dragX=dragStart.rx+dx*.006;state.dragY=Math.max(-1,Math.min(1,dragStart.ry+dy*.004));signal('render');}});
 const release=()=>{dragStart=null;state.isDragging=false;};drag?.addEventListener('pointerup',release);drag?.addEventListener('pointercancel',release);
 drag?.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();if(e.key==='ArrowLeft')state.dragX-=.12;if(e.key==='ArrowRight')state.dragX+=.12;if(e.key==='ArrowUp')state.dragY-=.12;if(e.key==='ArrowDown')state.dragY+=.12;signal('render');});
 document.querySelectorAll<HTMLButtonElement>('[data-lab-shape]').forEach(b=>b.addEventListener('click',()=>{state.shape=Number(b.dataset.labShape);state.shapeFrom=state.shape;state.shapeMix=1;document.querySelectorAll('[data-lab-shape]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));signal('render');}));
 const frequency=document.getElementById('frequency') as HTMLInputElement|null;
 const threshold=document.getElementById('threshold') as HTMLInputElement|null;
 function wave(){
  if(!frequency||!threshold)return;
  const f=Number(frequency.value),t=Number(threshold.value)/100;state.labFrequency=f;state.labThreshold=t;
  document.getElementById('frequency-value')!.textContent=String(f);document.getElementById('threshold-value')!.textContent=t.toFixed(2);
  let d='',selected=0;
  for(let i=0;i<=80;i++){const v=Math.sin(i/80*Math.PI*2*f)*.72+Math.cos(i/80*Math.PI*2*(f+1))*.13;d+=(i?'L':'M')+(i*3.75).toFixed(2)+','+(50-v*35).toFixed(2);if(i%2===0&&v>t)selected++;}
  document.getElementById('wave-path')?.setAttribute('d',d);
  document.getElementById('wave-threshold')?.setAttribute('d',`M0 ${50-t*35}H300`);
  document.getElementById('wave-readout')!.textContent=selected+' / 41 SAMPLES ABOVE THRESHOLD';signal('render');
 }
 frequency?.addEventListener('input',wave);threshold?.addEventListener('input',wave);
 document.getElementById('lab-reset')?.addEventListener('click',()=>{if(!frequency||!threshold)return;frequency.value='3';threshold.value='35';state.dragX=0;state.dragY=0;state.shape=0;state.shapeFrom=0;state.shapeMix=1;document.querySelectorAll<HTMLElement>('[data-lab-shape]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.labShape==='0')));wave();toast('Experiment reset.');});
 wave();
 document.getElementById('copy-email')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText('sanjarshaheed@gmail.com');toast('Email copied.');}catch{toast('Copy is unavailable. Use the email link or select the address.');}});

}
