import {toast,state} from '../state';
import projects from '../content/projects.json';
import {toggleMotion,toggleTheme,togglePause,toggleQuality,wireframe} from './settings';
export function mountPalette(){
 const dialog=document.getElementById('command-dialog') as HTMLDialogElement;
 const input=document.getElementById('command-query') as HTMLInputElement;
 const results=document.getElementById('command-results')!;
 if(!dialog||!input)return;
 let opener:HTMLElement|null=null;
 const commands=[
  {label:'Go to Work',hint:'SEVEN PROJECT WORLDS',url:'/#projects'},
  ...projects.map((p,i)=>({label:'Go to '+p.name.split(' — ')[0],hint:String(i+1).padStart(2,'0')+' — '+p.category,url:'/#'+p.id})),
  {label:'Go to Research',hint:'VISORA / AI LAB',url:'/#research'},
  {label:'Technology system',hint:'CONNECTED TOOLS',url:'/#stack'},
  {label:'Go to Lab',hint:'MANIPULATE THE CORE',url:'/#lab'},
  {label:'How I think',hint:'OBSERVE / MODEL / BUILD',url:'/#thinking'},
  {label:'Go to About',hint:'THE HUMAN',url:'/#about'},
  {label:'Contact',hint:'TRANSMISSION',url:'/#contact'},
  {label:'GitHub',hint:'PUBLIC WORK ↗',url:'https://github.com/ShaheedSanjar'},
  {label:'LinkedIn',hint:'CONNECT ↗',url:'https://www.linkedin.com/in/shaheedsanjar'},
  {label:'Resume',hint:'REQUEST BY EMAIL',url:'mailto:sanjarshaheed@gmail.com?subject=Resume%20request'},
  {label:'Toggle Theme',hint:'AUTO / LIGHT / DARK',action:toggleTheme},
  {label:'Reduce Motion',hint:'ACCESSIBILITY',action:toggleMotion},
  {label:'Pause Core',hint:'PAUSE / RESUME',action:togglePause},
  {label:'Rendering Quality',hint:'AUTO / ECO',action:toggleQuality},
 ];
 function close(){dialog.close();}
 function terminal(){
  wireframe();toast('SANJAR / local session. No remote shell. Structure inspection '+(state.wireframe?'enabled.':'disabled.'));
 }
 function render(){
  const q=input.value.trim().toLowerCase();
  const items=q==='sudo sanjar'?[{label:'SANJAR SYSTEM — ACCESS GRANTED',hint:'INSPECT LOCAL STRUCTURE',action:terminal}]:commands.filter(c=>(c.label+' '+c.hint).toLowerCase().includes(q));
  results.replaceChildren();
  for(const c of items){
   const a=document.createElement('url' in c?'a':'button');
   if('url' in c&&c.url){(a as HTMLAnchorElement).href=c.url;if(c.url.startsWith('https')){(a as HTMLAnchorElement).target='_blank';(a as HTMLAnchorElement).rel='noopener noreferrer';a.setAttribute('aria-label',c.label+' (opens a new tab)');}}
   const name=document.createElement('span'),hint=document.createElement('small');name.textContent=c.label;hint.textContent=c.hint;a.append(name,hint);
   a.addEventListener('click',()=>{close();if('action' in c)c.action?.();if('url' in c&&c.url?.startsWith('/#')&&location.pathname==='/'){const el=document.querySelector<HTMLElement>(c.url.slice(1));setTimeout(()=>{el?.setAttribute('tabindex','-1');el?.focus({preventScroll:true});},30);}});results.append(a);
  }
  if(!items.length){const p=document.createElement('p');p.className='command-empty';p.textContent='No match. Try a place, a project, or a system setting.';results.append(p);}
  document.getElementById('command-count')!.textContent=items.length+' COMMANDS';
 }
 function open(){if(dialog.open)return;opener=document.activeElement as HTMLElement;input.value='';render();dialog.showModal();input.focus();}
 document.querySelectorAll('[data-command]').forEach(b=>b.addEventListener('click',open));
 document.querySelector('[data-close]')?.addEventListener('click',close);
 dialog.addEventListener('close',()=>opener?.focus());
 dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close();});
 input.addEventListener('input',render);
 input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();results.querySelector<HTMLElement>('a,button')?.click();}});
 dialog.addEventListener('keydown',e=>{if(!['ArrowDown','ArrowUp'].includes(e.key))return;const items=[...results.querySelectorAll<HTMLElement>('a,button')];if(!items.length)return;e.preventDefault();const i=items.indexOf(document.activeElement as HTMLElement);items[e.key==='ArrowDown'?(i+1)%items.length:i<=0?items.length-1:i-1].focus();});
 document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();dialog.open?close():open();}});
}
