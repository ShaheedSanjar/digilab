import {state,signal,toast} from './state';
import {mountSettings} from './ui/settings';
import {mountPalette} from './ui/palette';
import {mountCursor} from './ui/cursor';
import {mountInteractions} from './ui/interactions';
document.documentElement.classList.add('experience-js');
mountSettings();mountPalette();mountCursor();mountInteractions();
const intro=document.getElementById('intro-screen');
function dismissIntro(){if(!intro)return;intro.classList.add('intro-complete');document.documentElement.classList.add('identity-ready');setTimeout(()=>{intro.hidden=true;},500);}
intro?.querySelector('button')?.addEventListener('click',dismissIntro);
if(state.reduced||location.hash)dismissIntro();else setTimeout(dismissIntro,1600);
window.addEventListener('sanjar:motion',()=>{if(state.reduced)dismissIntro();});
const mount=document.getElementById('core-stage');
let disposeCore:(()=>void)|undefined;
let disposeStory:(()=>void)|undefined;
if(mount){
 import('./motion').then(m=>{disposeStory=m.mountStory();}).catch(()=>document.documentElement.classList.add('scroll-fallback'));
 const probe=document.createElement('canvas');let webgl=false;
 try{const ctx=probe.getContext('webgl2');webgl=!!ctx;ctx?.getExtension('WEBGL_lose_context')?.loseContext();}catch{}
 if(webgl){
  // Keep identity and navigation independent of the optional graphics chunk.
  const load=()=>import('./core/renderer').then(m=>{if(state.alive)disposeCore=m.mountCore(mount)?.dispose;}).catch(()=>fallback());
  if('requestIdleCallback' in window)(window as Window & {requestIdleCallback:(cb:()=>void,opts:{timeout:number})=>number}).requestIdleCallback(load,{timeout:500});else setTimeout(load,80);
 }else fallback();
}
function fallback(){
 document.documentElement.classList.add('webgl-unavailable');
 const el=document.getElementById('render-status');if(el)el.textContent='STATIC / CORE';
 const note=document.getElementById('lab-fallback');if(note)note.hidden=false;
 const drag=document.getElementById('core-drag');if(drag)drag.setAttribute('aria-disabled','true');
}
window.addEventListener('sanjar:core-status',(e)=>{if((e as CustomEvent).detail.status==='fallback')fallback();});
// Page transitions use the browser's progressive cross-document View Transition support.
// Normal links remain valid if transitions, graphics or JavaScript are unavailable.
window.addEventListener('pagehide',()=>{state.alive=false;disposeCore?.();disposeStory?.();signal('dispose');});
window.addEventListener('pageshow',e=>{if(e.persisted)location.reload();});
