"""Optional regeneration of the original social preview (Pillow + fontTools)."""
from pathlib import Path
from io import BytesIO
from PIL import Image,ImageDraw,ImageFont
from fontTools.ttLib import TTFont
from math import sin,cos,pi
root=Path(__file__).resolve().parents[1];assets=root/'dist/assets'
f=TTFont(assets/'manrope-extra.woff');f.flavor=None;b=BytesIO();f.save(b)
def font(size):return ImageFont.truetype(BytesIO(b.getvalue()),size)
im=Image.new('RGB',(1200,630),'#0B0B0B');d=ImageDraw.Draw(im)
d.line((55,77,1145,77),fill='#6F4E37',width=1)
d.text((55,34),'SASS',font=font(19),fill='#E5E4E2')
d.text((859,38),'THE DIGITAL LAB',font=font(13),fill='#E5E4E2')
for i,t in enumerate(['MOHAMMED','SHAHEED','SANJAR']):d.text((51,118+i*103),t,font=font(91),fill='#E5E4E2',stroke_width=0)
# Original folio contours, rasterized directly for social metadata.
for i in range(29):
 y=125+i*7
 points=[(660,y+30),(755,y+68),(920,y-10),(1115,y+98),(920,y+205),(752,y+110),(915,y+24)]
 color=tuple(round(a+(b-a)*(i/40)) for a,b in zip((111,78,55),(229,228,226)))
 d.line(points,fill=color,width=1,joint='curve')
d.line([(660,155),(755,193),(920,115),(1115,223)],fill='#E6E0F8',width=2)
for x,y in [(660,155),(755,193),(920,115),(1115,223)]:d.ellipse((x-3,y-3,x+3,y+3),fill='#E6E0F8')

d.text((57,490),'Intelligent systems. Useful products.',font=font(17),fill='#E5E4E2')
d.line((55,561,1145,561),fill='#6F4E37',width=1)
d.text((55,585),'MOHAMMED SHAHEED SANJAR',font=font(12),fill='#E5E4E2');d.text((938,585),'PORTFOLIO / 2026',font=font(12),fill='#E5E4E2')
im.save(assets/'social-preview.png',optimize=True)
print('Social preview saved:',(assets/'social-preview.png').stat().st_size,'bytes')
