"""Static release checks for routes, assets, privacy surface and accessible markup."""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit,unquote
import re,json,gzip,collections
root=Path(__file__).resolve().parents[1];dist=root/'dist';errors=[];inventory={}
class Page(HTMLParser):
 def __init__(self,path):
  super().__init__(convert_charrefs=True);self.path=path;self.ids=[];self.links=[];self.assets=[];self.h1=0;self.lang=None;self.csp=False;self.external_scripts=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag=='html':self.lang=a.get('lang')
  if tag=='h1':self.h1+=1
  if tag=='meta' and a.get('http-equiv')=='Content-Security-Policy':self.csp=True
  if tag=='a':
   self.links.append(a.get('href',''))
   if a.get('target')=='_blank' and not {'noopener','noreferrer'}<=set(a.get('rel','').split()):errors.append(f'{self.path}: external link lacks safe rel')
  if tag in ['script','img'] and a.get('src'):self.assets.append(a['src'])
  if tag=='link' and a.get('rel') in ['stylesheet','icon','manifest','preload']:self.assets.append(a['href'])
  if tag=='img' and 'alt' not in a:errors.append(f'{self.path}: image missing alt')
  if tag=='script' and a.get('src','').startswith('http'):self.external_scripts.append(a['src'])
for f in dist.rglob('*.html'):
 p=Page(str(f.relative_to(dist)));p.feed(f.read_text());inventory[p.path]=p
 if p.lang!='en':errors.append(f'{p.path}: language')
 if p.h1!=1:errors.append(f'{p.path}: expected 1 h1, found {p.h1}')
 if not p.csp:errors.append(f'{p.path}: CSP missing')
 if len(p.ids)!=len(set(p.ids)):errors.append(f'{p.path}: duplicate ID')
 if '#main' not in p.links:errors.append(f'{p.path}: skip link missing')
 if p.external_scripts:errors.append(f'{p.path}: external scripts')
for name,p in inventory.items():
 for link in p.links+p.assets:
  u=urlsplit(link)
  if u.scheme or u.netloc:continue
  rel=unquote(u.path).lstrip('/') if u.path.startswith('/') else str(Path(name).parent/u.path)
  dest=dist/rel if u.path else dist/name
  if dest.is_dir():dest=dest/'index.html'
  if not dest.exists():errors.append(f'{name}: missing target {link}');continue
  if u.fragment and dest.suffix=='.html':
   target=inventory.get(str(dest.relative_to(dist)))
   if target and u.fragment not in target.ids:errors.append(f'{name}: missing fragment {link}')
# Audit our source, not unused network loaders inside the vendored Three.js bundle.
js='\n'.join(f.read_text() for f in (root/'src').rglob('*.ts'))
for term in ['localStorage','sessionStorage','indexedDB','document.cookie','fetch(', 'XMLHttpRequest','eval(', 'innerHTML','insertAdjacentHTML']:
 if term in js:errors.append(f'Unexpected runtime capability in application source: {term}')
css='\n'.join(f.read_text() for f in (dist/'assets').glob('*.css'))
for path in re.findall(r'url\([\'\"]?(/[^)\'\"]+)',css):
 if not (dist/path.lstrip('/')).is_file():errors.append(f'CSS missing asset: {path}')
for f in (dist/'assets/engine').glob('*.js'):
 for path in re.findall(r'(?:from\s*|import\s*\()\s*[\'\"](\./[^\'\"]+)',f.read_text()):
  if not (f.parent/path).is_file():errors.append(f'Missing engine chunk: {path}')
for required in ['Three-MIT.txt','GSAP-license.txt']:
 if not (dist/'assets/licenses'/required).is_file():errors.append('Missing license: '+required)
# Check CSS syntax using the installed parser when available.
try:
 import tinycss2
 css_errors=[str(r) for r in tinycss2.parse_stylesheet(css) if r.type=='error'];errors+=css_errors
except ImportError:pass
# User-specified release contract: exact project order and restricted palette.
expected=['visora','finvisor','travel','bankonex','mental-health','chatbot','investing']
actual=re.findall(r'<article id="([^"]+)" class="scene project-world', (dist/'index.html').read_text())
if actual!=expected:errors.append('Project chapter order differs from the approved brief')
allowed={'6f4e37','e5e4e2','e6e0f8','0b0b0b','151515','222222','ffffff','000000','fff','000'}
for file in list((dist/'assets').glob('*.css'))+list((dist/'assets').rglob('*.svg')):
 colors={c.lower()[1:] for c in re.findall(r'#[0-9a-fA-F]{3,8}\b',file.read_text())}
 if any(c not in allowed and c[:6] not in allowed for c in colors):errors.append('Unapproved palette color: '+str(file.relative_to(dist)))
for category in json.loads((root/'src/content/technologies.json').read_text()):
 for tech in category['nodes']:
  if any(p not in expected for p in tech['projects']):errors.append('Unknown technology/project relationship')
assets={str(f.relative_to(dist)):f.stat().st_size for f in dist.rglob('*') if f.is_file()}
first=['index.html','assets/site.css','assets/experience.css','assets/engine/experience.js','assets/signal-folio.svg','assets/manrope-regular.woff','assets/manrope-bold.woff','assets/manrope-extra.woff']
engine=[p for p in assets if p.startswith('assets/engine/') and p.endswith('.js')]
qa_path=root/'docs/browser-qa.json'
qa=json.loads(qa_path.read_text()) if qa_path.exists() else {'status':'not run'}
result={'date':'2026-10-22','html_pages':len(inventory),'static_routes_and_assets':'pass' if not errors else 'fail','errors':errors,'total_deploy_bytes':sum(assets.values()),'initial_page_assets_bytes':sum(assets[x] for x in first),'initial_page_assets_gzip_estimate':sum(len(gzip.compress((dist/x).read_bytes())) for x in first),'all_javascript_bytes':sum(assets[x] for x in engine),'all_javascript_gzip_estimate':sum(len(gzip.compress((dist/x).read_bytes())) for x in engine),'application_external_scripts':0,'application_persistent_storage':0,'browser_QA':qa,'lighthouse':'Not run','screen_reader_QA':'Not run','asset_sizes':assets}
(root/'docs').mkdir(exist_ok=True);(root/'docs/validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='asset_sizes'},indent=2))
if errors:raise SystemExit(1)
