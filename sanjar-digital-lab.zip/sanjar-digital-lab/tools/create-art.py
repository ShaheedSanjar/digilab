from pathlib import Path
from math import sin,cos,pi
p=Path(__file__).resolve().parents[1]/'dist'/'assets'
s=['<svg xmlns="http://www.w3.org/2000/svg" width="720" height="680" viewBox="0 0 720 680" fill="none">']
s.append('<g stroke="#6F4E37" stroke-width=".5">')
for x in range(80,701,60):s.append(f'<path d="M{x} 65V590"/>')
for y in range(80,601,60):s.append(f'<path d="M65 {y}H690"/>')
s.append('</g>')
for y in range(135,510,48):
 for x in range(68,220,36):s.append(f'<circle cx="{x}" cy="{y}" r="1.1" fill="#6F4E37"/>')
# A topological folio: parallel signal contours become a registered structure.
for i in range(29):
 y=106+i*8.8
 opacity=.24+.55*i/29
 s.append(f'<path d="M75 {y+90} C160 {y+75} 175 {y+155} 244 {y+137} L433 {y+50} Q453 {y+40} 474 {y+52} L659 {y+156} Q675 {y+165} 658 {y+175} L448 {y+286} Q429 {y+296} 410 {y+285} L236 {y+186} Q220 {y+176} 241 {y+164} L431 {y+69}" stroke="#E6E0F8" stroke-opacity="{opacity:.2f}" stroke-width=".85"/>')
# Constructed planes, dimension lines and a mocha and lavender signal spine.
s.append('<path d="M241 270L432 175L652 298L441 413Z" fill="#6F4E37" fill-opacity=".14" stroke="#E6E0F8" stroke-width="1.2"/>')
for i in range(1,12):
 t=i/12
 x=241+(432-241)*t;y=270+(175-270)*t
 s.append(f'<path d="M{x} {y} l211 128" stroke="#E6E0F8" stroke-opacity=".32" stroke-width=".7"/>')
for i in range(1,13):
 t=i/13;x=241+200*t;y=270+143*t
 s.append(f'<path d="M{x} {y} l211 -115" stroke="#E6E0F8" stroke-opacity=".32" stroke-width=".7"/>')
s.append('<path d="M69 196C161 181 175 261 244 243L433 156Q453 146 474 158L659 262" stroke="#E6E0F8" stroke-width="1.5"/><path d="M432 156V175M241 270V406M441 413V540" stroke="#E6E0F8" stroke-dasharray="2 5" stroke-opacity=".6"/>')
for x,y in [(69,196),(244,243),(433,156),(659,262),(441,413)]:s.append(f'<circle cx="{x}" cy="{y}" r="3" fill="#E6E0F8"/>')
s.append('<g stroke="#E5E4E2" stroke-width=".8"><path d="M680 255v255m-5-255h10m-10 255h10M265 563l175 100m-179-96l8-8m167 108l8-8M74 100v10m-5-5h10M685 105v10m-5-5h10"/></g><g fill="#E5E4E2" font-size="8" font-family="monospace" letter-spacing="2"><text x="68" y="88">INPUT / UNSTRUCTURED</text><text x="436" y="651">OUTPUT / RESOLVED</text><text x="690" y="386" transform="rotate(90 690 386)">STRUCTURE 001</text></g></svg>')
(p/'signal-folio.svg').write_text(''.join(s))
# Graphic contour map: no real location or external geographic data.
s=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 500" fill="none">']
for j in range(22):
 pts=[]
 for i in range(101):
  a=i/100*2*pi;r=25+j*13+13*sin(a*3+j*.09)+9*cos(a*5)
  pts.append((360+cos(a)*r,260+sin(a)*r*.72))
 s.append('<path d="M'+' L'.join(f'{x:.1f} {y:.1f}' for x,y in pts)+'Z" stroke="#6F4E37" stroke-width=".8"/>')
s.append('</svg>');(p/'contours.svg').write_text(''.join(s))
(p/'favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#0B0B0B"/><path d="M44 18H26l-9 14h30L37 46H19" fill="none" stroke="#E6E0F8" stroke-width="5"/></svg>')
print('Created original SVG artwork.')
