import {build} from 'esbuild';
import {execFileSync} from 'node:child_process';
import {mkdir,writeFile,copyFile,readFile,readdir,rm} from 'node:fs/promises';
execFileSync('python',['tools/build-pages.py'],{stdio:'inherit'});
await mkdir('dist/assets/engine',{recursive:true});
for(const f of await readdir('dist/assets/engine')) await rm('dist/assets/engine/'+f,{force:true});
const result=await build({entryPoints:{experience:'src/experience.ts'},bundle:true,splitting:true,format:'esm',target:['es2022'],outdir:'dist/assets/engine',entryNames:'[name]',chunkNames:'[name]-[hash]',minify:true,metafile:true,legalComments:'linked',sourcemap:false,logLevel:'info'});
await writeFile('docs/bundle-manifest.json',JSON.stringify(Object.fromEntries(Object.entries(result.metafile.outputs).map(([k,v])=>[k,{bytes:v.bytes,imports:v.imports,entryPoint:v.entryPoint}])),null,2));
await copyFile('src/styles/experience.css','dist/assets/experience.css');
await mkdir('dist/assets/licenses',{recursive:true});
for(const [pkg,name] of [['three','Three-MIT.txt'],['gsap','GSAP-license.txt']]){
 let copied=false;
 for(const file of ['LICENSE','LICENSE.md','LICENSE.txt']){
  try{await copyFile('node_modules/'+pkg+'/'+file,'dist/assets/licenses/'+name);copied=true;break;}catch{}
 }
 // GSAP distributes its authoritative license URL and copyright in README.md.
 if(!copied){const readme=await readFile('node_modules/'+pkg+'/README.md','utf8');const license=readme.slice(readme.indexOf('### License'));if(!license.startsWith('### License'))throw Error('Missing licensing notice: '+pkg);await writeFile('dist/assets/licenses/'+name,license);}
}
console.log('Built the Core experience. All runtime assets are self-hosted.');
