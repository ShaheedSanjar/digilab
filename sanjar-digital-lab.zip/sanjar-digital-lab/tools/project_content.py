"""Verified project content and original conceptual diagrams for the Digital Lab."""
from pathlib import Path
from html import escape
import json, math
ROOT=Path(__file__).resolve().parents[1]
PROJECTS=json.loads((ROOT/'src/content/projects.json').read_text())
P='#E5E4E2';L='#E6E0F8';M='#6F4E37';N='#0B0B0B'
def art(p):
 s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 440" fill="none"><g stroke="{P}" stroke-opacity=".13" stroke-width=".7">']
 for x in range(60,661,50):s.append(f'<path d="M{x} 45V395"/>')
 for y in range(45,396,50):s.append(f'<path d="M60 {y}H660"/>')
 s.append('</g>');motif=p['motif']
 if motif=='layers':
  for layer in range(5):
   x=75+layer*115;y=80+layer*15;size=195-layer*21
   color=M if layer<2 else L if layer<4 else P
   s.append(f'<g transform="translate({x} {y}) skewY(-17)" stroke="{color}"><rect width="{size}" height="{size}" fill="{N}" fill-opacity=".68" stroke-width="1.3"/>')
   for r in range(7):
    for c in range(7):
     opacity=.07+((r*3+c*5+layer*7)%13)/24
     unit=size/8
     s.append(f'<rect x="{unit*(c+.5):.1f}" y="{unit*(r+.5):.1f}" width="{unit*.75:.1f}" height="{unit*.75:.1f}" fill="{color}" fill-opacity="{opacity:.2f}" stroke="none"/>')
   s.append('</g>')
  s.append(f'<path d="M75 350C200 350 450 290 620 290" stroke="{M}" stroke-width="2" stroke-dasharray="3 7"/>')
 elif motif=='signals':
  for line in range(9):
   points=[]
   for i in range(61):
    x=65+i*9.2;y=290-line*18-math.sin(i*.13+line*.25)*25-math.exp(-((i-42)/12)**2)*60
    points.append(f'{x:.1f},{y:.1f}')
   s.append(f'<polyline points="{" ".join(points)}" stroke="{L if line==8 else P}" stroke-width="{1.5 if line==8 else .7}" opacity="{.3+line*.07:.2f}"/>')
  for i in range(13):
   x=75+i*43;h=18+(i*23)%77;s.append(f'<path d="M{x} 365v-{h}" stroke="{M}" stroke-width="12"/>')
 elif motif=='routes':
  for i in range(9):
   s.append(f'<path d="M{40+i*11} 350C{180+i*6} {90+i*8} {390-i*8} {420-i*14} 640 {70+i*24}" stroke="{M if i==4 else P}" opacity="{1 if i==4 else .17}" stroke-width="{2 if i==4 else .7}"/>')
  for x,y in [(84,350),(220,222),(387,237),(531,211),(640,166)]:
   s.append(f'<circle cx="{x}" cy="{y}" r="17" stroke="{P}" opacity=".3"/><circle cx="{x}" cy="{y}" r="4" fill="{L}"/>')
 elif motif=='ledger':
  for i in range(7):
   y=80+i*40;shift=(i%2)*35
   s.append(f'<path d="M{85+shift} {y}H{580+shift}L{620+shift} {y+22}H{125+shift}Z" fill="{N}" fill-opacity=".65" stroke="{P if i%3 else M}" stroke-width="1"/>')
   for j in range(6):s.append(f'<path d="M{150+shift+j*69} {y+8}h35" stroke="{L if j==4 else P}" opacity=".5"/>')
  s.append(f'<path d="M385 65V375" stroke="{M}" stroke-width="2" stroke-dasharray="2 6"/>')
 elif motif=='distribution':
  for j in range(15):
   pts=[]
   for i in range(71):
    x=60+i*8.2;y=345-j*4-150*math.exp(-((i-36-j*.4)/13)**2)
    pts.append(f'{x:.1f},{y:.1f}')
   s.append(f'<polyline points="{" ".join(pts)}" stroke="{M if j==7 else L}" opacity="{.8 if j==7 else .14+j*.025}"/>')
  for i in range(70):
   x=75+((i*83)%550);y=95+((i*59)%240)
   s.append(f'<circle cx="{x}" cy="{y}" r="1.2" fill="{P}" opacity=".4"/>')
 elif motif=='semantics':
  nodes=[(90,210),(230,110),(250,245),(225,350),(420,160),(440,290),(605,210)]
  for a,b in [(0,1),(0,2),(0,3),(1,4),(2,4),(2,5),(3,5),(4,6),(5,6)]:
   x,y=nodes[a];xx,yy=nodes[b];s.append(f'<path d="M{x} {y}Q{(x+xx)/2} {y} {xx} {yy}" stroke="{M if a==2 else P}" opacity=".65"/>')
  for i,(x,y) in enumerate(nodes):
   s.append(f'<circle cx="{x}" cy="{y}" r="{20+i%3*6}" fill="{N}" stroke="{L if i in [2,4] else P}"/><circle cx="{x}" cy="{y}" r="3" fill="{M if i==0 else L}"/>')
 elif motif=='accumulation':
  for j in range(6):
   for i in range(11-j):
    x=70+i*17;y=90+j*50;s.append(f'<circle cx="{x}" cy="{y}" r="2" fill="{P}" opacity=".6"/>')
   s.append(f'<path d="M270 {90+j*50}C380 {90+j*50} 380 220 500 220" stroke="{M}" opacity=".65"/>')
  for i in range(10):
   y=165+i*13;s.append(f'<path d="M500 {y}l60-30 60 30-60 30Z" stroke="{L if i==0 else P}" fill="{N}" fill-opacity=".7" opacity="{1-i*.06:.2f}"/>')
 s.append('</svg>');return ''.join(s)
def generate_art():
 folder=ROOT/'dist/assets/worlds';folder.mkdir(exist_ok=True)
 for p in PROJECTS:(folder/(p['id']+'.svg')).write_text(art(p))
def chapters():
 index=''.join(f'<a href="#{p["id"]}" data-project-index="{p["id"]}"><span>{i:02}</span>{escape(["VISORA","FINVISOR","TRAVEL","BANKONEX","MENTAL HEALTH","CHATBOT","INVESTING"][i-1])}</a>' for i,p in enumerate(PROJECTS,1))
 out=[f'<nav class="project-index" aria-label="Project index"><span class="index-caption">SELECTED WORK / 07</span><div>{index}</div></nav>']
 for i,p in enumerate(PROJECTS,1):
  controls=''.join(f'<button data-story-step="{k}" aria-pressed="{str(j==0).lower()}">{label}</button>' for j,(k,label,_) in enumerate(p['perspectives']))
  copy=''.join(f'<p data-story-copy="{k}"'+(' hidden' if j else '')+f'>{escape(text)}</p>' for j,(k,_,text) in enumerate(p['perspectives']))
  titleclass='chapter-title'+(' compact-title' if p['id'] in ['mental-health','chatbot','investing'] else ' two-line' if '<br>' in p['title'] else '')
  newest='<span class="featured-badge">LATEST / FEATURED</span>' if p.get('newest') else ''
  tech=' / '.join(escape(t) for t in p['tech'])
  out.append(f'''<article id="{p['id']}" class="scene project-world world-{p['motif']}" data-scene="{p['id']}" data-scene-label="{i:02} / {p['name'].split(' — ')[0].upper()}" data-project-world aria-labelledby="{p['id']}-title"><div class="scene-panel">
<div class="scene-code meta"><span>{i:02} / {p['category']}</span>{newest}</div><span class="chapter-number" aria-hidden="true">{i:02}</span>
<div class="chapter-kicker meta">{escape(p['subtitle'])}</div><h3 id="{p['id']}-title" class="{titleclass}" data-project-title="{p['id']}">{p['title']}<span class="title-period">.</span></h3><p class="chapter-description">{escape(p['description'])}</p>
<figure class="chapter-graphic" aria-hidden="true"><img src="/assets/worlds/{p['id']}.svg" alt="" width="700" height="440" loading="lazy"><figcaption>{'FEATURE LEARNING / CONCEPTUAL REPRESENTATION' if p['id']=='visora' else 'CONCEPTUAL SYSTEM / '+p['motif'].upper()}</figcaption></figure>
<div class="chapter-lower"><div class="chapter-story"><p class="chapter-question">{p['question']}</p><div class="story-controls" role="group" aria-label="{escape(p['name'])} project perspectives">{controls}</div><div class="story-copy" aria-live="polite">{copy}</div><a class="scene-link magnetic" href="/projects/{p['slug']}/" data-cursor="EXPLORE">EXPLORE THE PROJECT <span aria-hidden="true">↗</span></a></div><div class="chapter-tech"><span class="meta">TECHNOLOGY</span><p>{tech}</p></div></div><div class="scene-baseline"><span class="meta">{' → '.join(p['flow'])}</span><span class="meta">{i:02} / 07</span></div>
</div></article>''')
 return '\n'.join(out)
def cases():
 out={}
 for i,p in enumerate(PROJECTS,1):
  repo=(f'<a href="{p["repo"]}" target="_blank" rel="noopener noreferrer">View public project materials ↗ (opens a new tab)</a>. ' if p.get('repo') else '')
  if p.get('repo'):
   repo+=' '.join(f'<a href="{p["repo"]}/blob/main/{name}" target="_blank" rel="noopener noreferrer">{label} ↗ (opens a new tab)</a>.' for name,label in [('Smart_College_Chatbot_Report.docx','Report'),('Smart_College_Chatbot_PPT.pptx','Presentation'),('Smart_College_Chatbot_ZIP.zip','Implementation archive')])
  elif p['id']!='visora':repo='<a href="https://shaheedsanjar.vercel.app/" target="_blank" rel="noopener noreferrer">Original portfolio ↗ (opens a new tab)</a>. '
  email=f'<a href="mailto:sanjarshaheed@gmail.com?subject={p["id"]}%20project%20details">Request project material ↗</a>.'
  visual=f'<figure class="case-system-visual"><img src="/assets/worlds/{p["id"]}.svg" alt="Abstract {p["motif"]} representation of the project" width="700" height="440"><figcaption>CONCEPTUAL REPRESENTATION / NOT A PRODUCT SCREENSHOT OR MODEL OUTPUT</figcaption></figure>'
  a={x[0]:x[2] for x in p['perspectives']}
  out[p['slug']]={'title':p['name'],'label':f'{i:02} / {p["category"]}','lead':p['description'],'overview':p['overview'],'problem':a['problem'],'solution':a['approach'],'engineering':p['engineering'],'experience':a['system']+' '+a['output'],'evidence':repo+('Project information supplied directly by the owner in the current brief. ' if p['id']=='visora' else 'Description confirmed by the existing portfolio and the owner’s current brief. ')+email,'status':p['status'],'limits':p['limits'],'flow':p['flow'],'visual':visual}
 return out
