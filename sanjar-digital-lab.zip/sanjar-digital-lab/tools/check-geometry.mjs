import {build} from 'esbuild';
import assert from 'node:assert/strict';
const {outputFiles}=await build({entryPoints:['src/core/geometry.ts'],bundle:true,platform:'node',format:'esm',write:false});
const {createCoreGeometry}=await import('data:text/javascript;base64,'+Buffer.from(outputFiles[0].contents).toString('base64'));
for(const mobile of [false,true]){
 const {points,lines,count}=createCoreGeometry(mobile);
 assert(count>0&&count<65536,'Geometry fits the index type');
 const attributes=Object.values(points.attributes);
 assert(attributes.every(a=>a.count===count),'All morph attributes share the same topology');
 assert(attributes.every(a=>Array.from(a.array).every(Number.isFinite)),'All geometry values are finite');
 assert(Array.from(lines.index.array).every(i=>i>=0&&i<count),'Every line references an existing vertex');
 for(let i=1;i<10;i++)assert(points.getAttribute('aShape'+i).array.some((n,k)=>Math.abs(n-points.getAttribute('position').array[k])>.01),'Each state is geometrically distinct');
 assert.equal(lines.index.count%2,0,'Line segments use complete pairs');
 points.dispose();lines.dispose();
 console.log(`${mobile?'mobile':'desktop'} geometry: ${count} samples; attributes and topology valid`);
}
