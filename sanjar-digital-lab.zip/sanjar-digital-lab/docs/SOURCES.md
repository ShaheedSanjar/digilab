# Content provenance

Checked 22 October 2026. The latest owner-supplied brief, `Pasted text(4).txt`, controls the project order, new VISORA description and strict palette. The existing public portfolio remains the source for identity, experience and established project details:

https://shaheedsanjar.vercel.app/

The page is client-rendered. Its public page and content bundle were fetched to read descriptions and links. No layout, animation, source implementation, proprietary image, or visual asset from that site was copied into this project.

## Included facts

| Content | Source and treatment |
| --- | --- |
| Full name and AI/software/product framing | User's attached brief; identity matches existing portfolio. |
| B.Tech in Computer Science Engineering, SR University; started 2024 | Existing portfolio. No graduation date or degree completion invented. |
| VISORA | Owner’s latest brief: newest project, visual image classification, Python, CNN, Deep Learning and Fashion-MNIST. No framework, exact layer count, split, accuracy or trained model supplied. |
| FinVisor — Finance Friend | Existing portfolio description and Python/React/FastAPI/Pandas stack. No model, metric, or live release claim. |
| Smart College Chatbot | Existing portfolio description and Python/Sentence Transformers/Flask/React stack. |
| Travel Planner — Smart Travel Guide | Existing portfolio description and React/Vite/Tailwind/Flask stack. No AI claim. |
| BankOneX | Existing portfolio: desktop banking application, Java/MySQL. No audit or security certification claimed. |
| Mental Health Risk Predictor | Existing portfolio: survey-based risk-indicator ML project, Python/Scikit-learn/Pandas/NumPy. Academic only; no diagnostic or clinical validation claim. |
| Spare Change Investing Platform | Existing portfolio concept/description, React/FastAPI/SQL. No real transactions, returns, or financial licensing claim. |
| Data Analyst Intern, Distractions Wear Pvt. Ltd., May–July 2026 | Existing portfolio. Responsibilities paraphrased; certificates are not shown as independently verified. |
| Operations & Project Coordination, Innovative Services, family business, 2020–present | Existing portfolio. Client logos and bank partnership implications deliberately omitted. |
| Skills | Taken from existing portfolio's programming, frontend, backend, machine learning, database, and tools lists. No invented proficiency ratings. |
| Contact | `sanjarshaheed@gmail.com`, https://github.com/ShaheedSanjar, https://www.linkedin.com/in/shaheedsanjar — linked in the source. Public phone number omitted for data minimization. |

## Independently inspected public evidence

The GitHub account and repository lists were retrieved through the public GitHub API.

- https://github.com/ShaheedSanjar/Smart-College-Chatbot — public tree contains `README.md`, `Smart_College_Chatbot_Report.docx`, `Smart_College_Chatbot_PPT.pptx`, and `Smart_College_Chatbot_ZIP.zip`. README says “NLP PROJECT”. This redesign verifies their presence and links to them; it does not claim to have audited or executed the archive.
- https://github.com/ShaheedSanjar/NLP — public tree contains multiple `.ipynb` assignment notebooks. Their existence supports a study archive. No claims about specific notebook methods, results, datasets, peer review, or publications are made.

## Omitted or flagged

VISORA was absent from the original source inspection, but is now explicitly confirmed and described in the owner’s latest brief and is included as project 01. The required seven-project order is VISORA, FinVisor, Travel Planner, BankOneX, Mental Health Risk Predictor, Smart College Chatbot, and Spare Change Investing Platform. Other previously suggested projects remain outside the requested seven-project selection. Node.js and PostgreSQL are included in the stated toolkit without inventing a project association.

No résumé URL, original product screenshots, publication citations, independently verified performance metrics, actual users, awards, or operational deployment details were supplied in the current source. Missing links are replaced with honest evidence notes or a résumé request email action.

All project-interface compositions are new, labeled illustrations. Lab signal values and FinVisor signal traces are synthetic demonstration data; no displayed values imply impact or product performance. The Lab experiment itself is implemented in this portfolio and is therefore actual new work.

## Other primary sources

- Manrope font: https://fonts.google.com/specimen/Manrope
- Font license: https://github.com/google/fonts/blob/main/ofl/manrope/OFL.txt — exact SIL OFL text included.
- India DPDP Act 2023: https://www.meity.gov.in/static/uploads/2024/06/2bf1f0e9f04e6fb4f8fef35e82c42aa5.pdf
- Final DPDP Rules 2025, notification: https://www.meity.gov.in/static/uploads/2025/11/53450e6e5dc0bfa85ebd78686cadad39.pdf
- DPDP Act commencement notification: https://www.meity.gov.in/static/uploads/2025/11/c56ceae6c383460ca69577428d36828b.pdf

The final notifications use phased commencement. Confirm the provisions effective on the actual launch date; this project does not provide a legal compliance determination.
